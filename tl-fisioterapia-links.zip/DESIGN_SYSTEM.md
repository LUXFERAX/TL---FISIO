# TL Fisioterapia e Pilates - Design System

## Paleta de Cores (baseada na logo)

### Cores Primárias
- **Roxo Escuro (Fundo)**: `#1a0f2e` ou `#0f0a1f` (aproximadamente)
- **Roxo Secundário (Círculo)**: `#a855b8` ou `#b565c8` (tom roxo vibrante)
- **Verde-Limão (Accent)**: `#d4ff00` ou `#e0ff00` (amarelo-verde vibrante)
- **Branco (Texto)**: `#ffffff` ou `#f5f5f5`

### Cores Complementares
- **Branco Suave**: `#e8e8e8` (para elementos secundários)
- **Cinza Escuro**: `#2a2a2a` (para sombras)

## Elementos Visuais

### Logo
- Figura humana estilizada em movimento (verde-limão)
- Círculo com borda roxo-magenta
- Bola/ponto acima (verde-limão)
- Texto "T.L." em branco
- Subtítulo "FISIOTERAPIA E PILATES" em branco com "E PILATES" em verde-limão

### Estilo Visual
- **Tema**: Vida Fit, Saúde, Movimento, Energia
- **Atmosfera**: Profissional, Moderno, Dinâmico
- **Inspiração**: Movimento, Vitalidade, Bem-estar

## Tipografia

### Fontes Recomendadas
- **Títulos**: Montserrat Bold ou Poppins Bold (peso 700)
- **Subtítulos**: Montserrat SemiBold ou Poppins SemiBold (peso 600)
- **Corpo**: Inter ou Poppins Regular (peso 400-500)

## Animações

### Botões
- Hover: Escala suave (1.05x) com mudança de cor
- Click: Feedback visual com transição de cor
- Duração: 300-400ms

### Elementos
- Fade-in ao carregar
- Slide suave em hover
- Glow effect para elementos destacados

## Segurança & Boas Práticas

### Segurança
1. **HTTPS**: Todos os links devem ser HTTPS
2. **Validação de Links**: Verificar se todos os links são válidos
3. **Proteção de Email**: Usar formato seguro para email (não expor diretamente)
4. **Meta Tags**: Incluir tags de segurança (CSP, X-Frame-Options)
5. **Responsividade**: Testar em múltiplos dispositivos

### Performance
1. **Otimização de Imagens**: Usar formatos modernos (WebP)
2. **Lazy Loading**: Carregar imagens sob demanda
3. **Minificação**: CSS e JS minificados
4. **Cache**: Configurar headers de cache apropriados

### Acessibilidade
1. **ARIA Labels**: Adicionar labels para leitores de tela
2. **Contraste**: Garantir contraste suficiente entre texto e fundo
3. **Teclado**: Navegação completa via teclado
4. **Alt Text**: Descrever imagens para usuários com deficiência visual

## Informações do Cliente

### Contatos
- **Email**: tlfisioterapia@gmail.com
- **WhatsApp 1**: (65) 9 9817-1995
- **WhatsApp 2**: (65) 99623-xxxx (a confirmar)

### Endereço
- **Av João Gomes Sobrinho, 98, Lixeira, Cuiabá - MT**

### Horários
- **Segunda a Quinta**: 7h às 18h (com agendamento)
- **Sexta**: Não atendemos (logística)
- **Importante**: Apenas com horário agendado

### Links Importantes
- **Instagram**: @tlfisioterapia
- **Facebook**: T.L. Fisioterapia
- **Curso/Apostila**: https://pay.kiwify.com.br/6loaeGQ

## Estrutura da Página

### Seções
1. **Header**: Logo + Breve descrição
2. **Sobre**: Parágrafo sobre a empresa
3. **Botões de Ação**: WhatsApp (x2), Facebook, Instagram, Email, Curso
4. **Rodapé**: Endereço, Horários, Copyright
