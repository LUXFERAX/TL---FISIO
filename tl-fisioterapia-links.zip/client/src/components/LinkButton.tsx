import { LucideIcon } from 'lucide-react';

interface LinkButtonProps {
  href: string;
  icon: LucideIcon;
  label: string;
  description?: string;
  external?: boolean;
  className?: string;
}

export default function LinkButton({
  href,
  icon: Icon,
  label,
  description,
  external = true,
  className = '',
}: LinkButtonProps) {
  return (
    <a
      href={href}
      target={external ? '_blank' : undefined}
      rel={external ? 'noopener noreferrer' : undefined}
      className={`
        group relative inline-flex items-center justify-center
        px-6 py-3 md:px-8 md:py-4
        bg-transparent border-2 border-[#d4ff00] rounded-lg
        transition-all duration-300 ease-out
        hover:bg-[#d4ff00] hover:shadow-lg hover:shadow-[#d4ff00]/50
        active:scale-95
        focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#d4ff00] focus-visible:ring-offset-2 focus-visible:ring-offset-[#1a0f2e]
        ${className}
      `}
    >
      <div className="flex items-center gap-3">
        <Icon
          size={24}
          className="text-[#d4ff00] group-hover:text-[#1a0f2e] transition-colors duration-300"
          strokeWidth={2.5}
        />
        <div className="text-left">
          <p className="font-semibold text-[#d4ff00] text-base group-hover:text-[#1a0f2e] transition-colors duration-300">
            {label}
          </p>
          {description && (
            <p className="text-xs text-gray-300 group-hover:text-[#1a0f2e]/70 transition-colors duration-300">
              {description}
            </p>
          )}
        </div>
      </div>
    </a>
  );
}
