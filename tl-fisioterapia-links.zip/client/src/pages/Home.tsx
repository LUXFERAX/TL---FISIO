import { Mail, MessageCircle, Facebook, Instagram, BookOpen, MapPin, Clock } from 'lucide-react';
import LinkButton from '@/components/LinkButton';

export default function Home() {
  const whatsappNumbers = [
    { number: '5565998171995', label: 'WhatsApp (Tatau)' },
    { number: '5565996231995', label: 'WhatsApp (Luiz)' },
  ];

  return (
    <div className="min-h-screen bg-[#1a0f2e] text-white overflow-hidden">
      {/* Background pattern */}
      <div className="fixed inset-0 opacity-10 pointer-events-none">
        <img
          src="https://d2xsxph8kpxj0f.cloudfront.net/310519663418235580/YDxAcxiQ5v7NybZS9ipQVC/tl-movement-pattern-EwVnyUvqMLDyv93PqjasN2.webp"
          alt="background pattern"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Hero Background */}
      <div className="relative w-full h-64 md:h-80 overflow-hidden">
        <img
          src="https://d2xsxph8kpxj0f.cloudfront.net/310519663418235580/YDxAcxiQ5v7NybZS9ipQVC/tl-hero-background-Q6Hsc66fAdQAz83S8GZnyx.webp"
          alt="TL Fisioterapia Hero"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#1a0f2e]" />
      </div>

      {/* Main Content */}
      <div className="relative z-10 px-4 md:px-6 py-8 md:py-12">
        <div className="max-w-2xl mx-auto">
          {/* Logo and Title */}
          <div className="text-center mb-8 md:mb-12 animate-slide-in-up">
            <div className="mb-6 flex justify-center">
              <img
                src="/tl-logo.png"
                alt="TL Fisioterapia Logo"
                className="h-32 md:h-40 drop-shadow-lg"
              />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-2 text-[#d4ff00]">
              TL Fisioterapia e Pilates
            </h1>
            <p className="text-lg text-gray-300 mb-6">
              Saúde, Movimento e Bem-estar
            </p>
          </div>

          {/* About Section */}
          <div className="bg-gradient-to-br from-[#2d1b4e] to-[#1a0f2e] border border-[#a855b8]/50 rounded-2xl p-6 md:p-8 mb-10 md:mb-12 backdrop-blur-sm animate-slide-in-up" style={{ animationDelay: '0.1s' }}>
            <p className="text-gray-200 text-center leading-relaxed text-base md:text-lg">
              A <span className="text-[#d4ff00] font-semibold">TL Fisioterapia e Pilates</span> é uma clínica especializada em fisioterapia e pilates, dedicada a promover a saúde, recuperação e bem-estar dos nossos pacientes. Com profissionais qualificados e equipamentos modernos, oferecemos atendimento personalizado para cada necessidade, ajudando você a recuperar movimento, fortalecer o corpo e melhorar sua qualidade de vida.
            </p>
          </div>

          {/* Links Section */}
          <div className="mb-12 md:mb-16 flex flex-col items-center">
            <h2 className="text-2xl md:text-3xl font-bold text-center mb-8 text-[#d4ff00]">
              Entre em Contato
            </h2>

            {/* Links Grid */}
            <div className="flex flex-col gap-3 w-full max-w-sm">
              {/* WhatsApp Buttons */}
              {whatsappNumbers.map((wp, index) => (
                <div key={index} className="animate-slide-in-up" style={{ animationDelay: `${0.3 + index * 0.05}s` }}>
                  <LinkButton
                    href={`https://wa.me/${wp.number}`}
                    icon={MessageCircle}
                    label={wp.label}
                    description="Envie uma mensagem"
                    className="w-full justify-start"
                  />
                </div>
              ))}

              {/* Email Button */}
              <div className="animate-slide-in-up" style={{ animationDelay: '0.5s' }}>
                <LinkButton
                  href="mailto:tlfisioterapia@gmail.com"
                  icon={Mail}
                  label="Email"
                  description="tlfisioterapia@gmail.com"
                  external={false}
                  className="w-full justify-start"
                />
              </div>

              {/* Facebook Button */}
              <div className="animate-slide-in-up" style={{ animationDelay: '0.55s' }}>
                <LinkButton
                  href="https://www.facebook.com/tlfisioterapiaa/"
                  icon={Facebook}
                  label="Facebook"
                  description="Siga-nos no Facebook"
                  className="w-full justify-start"
                />
              </div>

              {/* Instagram Button */}
              <div className="animate-slide-in-up" style={{ animationDelay: '0.6s' }}>
                <LinkButton
                  href="https://www.instagram.com/tlfisioterapia/"
                  icon={Instagram}
                  label="Instagram"
                  description="@tlfisioterapia"
                  className="w-full justify-start"
                />
              </div>

              {/* Course Button */}
              <div className="animate-slide-in-up" style={{ animationDelay: '0.65s' }}>
                <LinkButton
                  href="https://pay.kiwify.com.br/6loaeGQ?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQMMjU2MjgxMDQwNTU4AAGnSRZNtbwvlYTuoyVGYxWD4yM3XzowrGoXNOX88e2XYPsBM1qO2uDufJdIqcY_aem_ZvhpO6IkJ7-JseNN5AaSyw&utm_id=97760_v0_s00_e0_tv3_a1denn"
                  icon={BookOpen}
                  label="Curso & Apostila"
                  description="Acesse nosso material exclusivo"
                  className="w-full justify-start"
                />
              </div>
            </div>
          </div>

          {/* Footer Info */}
          <div className="bg-gradient-to-br from-[#2d1b4e] to-[#1a0f2e] border border-[#a855b8]/50 rounded-2xl p-6 md:p-8 backdrop-blur-sm animate-slide-in-up mx-auto" style={{ animationDelay: '0.2s' }}>
            <div className="space-y-6">
              {/* Location */}
              <div className="flex gap-4 items-start">
                <MapPin className="text-[#d4ff00] flex-shrink-0 mt-1" size={24} />
                <div>
                  <h3 className="font-semibold text-[#d4ff00] mb-1">Localização</h3>
                  <p className="text-gray-300 text-sm md:text-base">
                    Av João Gomes Sobrinho, 98<br />
                    Lixeira, Cuiabá - MT
                  </p>
                </div>
              </div>

              {/* Hours */}
              <div className="flex gap-4 items-start">
                <Clock className="text-[#d4ff00] flex-shrink-0 mt-1" size={24} />
                <div>
                  <h3 className="font-semibold text-[#d4ff00] mb-1">Horários</h3>
                  <p className="text-gray-300 text-sm md:text-base">
                    Segunda a Quinta: 7h às 18h<br />
                    <span className="text-[#d4ff00]">⚠️ Apenas com agendamento prévio</span><br />
                    <span className="text-gray-400 text-xs">Não atendemos sexta-feira</span>
                  </p>
                </div>
              </div>

              {/* Contact */}
              <div className="pt-4 border-t border-[#4c2d6f]">
                <p className="text-gray-400 text-xs md:text-sm text-center">
                  © 2026 TL Fisioterapia e Pilates. Todos os direitos reservados.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>


    </div>
  );
}
